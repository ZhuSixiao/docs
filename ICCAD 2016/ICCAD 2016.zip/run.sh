file=sigproc-sp
xelatex $file".tex" &&
pdfopen $file".pdf"
